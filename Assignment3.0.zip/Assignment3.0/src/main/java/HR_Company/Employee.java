package HR_Company;

import jakarta.persistence.*;

@Entity
public class Employee extends Manager {

    public Employee(int age, int workExperience, String firstName, String lastName, int salary) {
        super( age, workExperience,firstName, lastName, salary);
        if (workExperience >= 0 && workExperience <= 5) {
            setSalary(10000);
        } else if (workExperience > 5 && workExperience <= 10) {
            setSalary(15000);
        } else if(workExperience > 10 && workExperience <= 15){
            setSalary(20000);
        } else if(workExperience > 15 && workExperience <= 20){
            setSalary(25000);
        } else if(workExperience > 20 && workExperience <= 25){
            setSalary(30000);
        } else if(workExperience > 25 && workExperience <= 30){
            setSalary(35000);
        }
    }

    public Employee() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}