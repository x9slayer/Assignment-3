package HR_Company;

import jakarta.persistence.*;

@Entity

public class RegionalManager extends GeneralManager {

    public RegionalManager(int age, int workExperience, String firstName, String lastName, int salary) {
        super( age, workExperience,firstName, lastName,salary);
        if (workExperience >= 0 && workExperience <= 5) {
            setSalary(50000);
        } else if (workExperience > 5 && workExperience <= 10) {
            setSalary(55000);
        } else if(workExperience > 10 && workExperience <= 15){
            setSalary(60000);
        } else if(workExperience > 15 && workExperience <= 20){
            setSalary(65000);
        } else if(workExperience > 20 && workExperience <= 25){
            setSalary(70000);
        } else if(workExperience > 25 && workExperience <= 30){
            setSalary(75000);
        }
    }

    public RegionalManager() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}