package HR_Company;

import jakarta.persistence.*;

@Entity

public class GeneralManager {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    protected Long id;
    protected String firstName;
    protected String lastName;
    protected int age;
    protected int workExperience;
    protected int salary;

    public GeneralManager(int age, int workExperience,String firstName, String lastName , int salary) {
        this.age = age;
        this.workExperience = workExperience;
        this.firstName = firstName;
        this.lastName = lastName;
        this.salary = salary;
    }

    public GeneralManager() {

    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public int getWorkExperience() {
        return workExperience;
    }

    public void setWorkExperience(int workExperience) {
        this.workExperience = workExperience;
    }

    public int getSalary() {
        return salary;
    }

    public void setSalary(int salary) {
        this.salary = salary;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}