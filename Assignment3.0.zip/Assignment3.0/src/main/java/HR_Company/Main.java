package HR_Company;

import HIbernate.Hibernate;
import org.w3c.dom.ls.LSOutput;

import java.awt.geom.GeneralPath;
import java.util.ArrayList;
import java.util.Scanner;

public class Main {

    private static ArrayList<GeneralManager> employeeList = new ArrayList<>();
    private static Scanner sc = new Scanner(System.in);


    public static void main(String[] args) {
        employeeList.addAll(Hibernate.getDataFromDB(GeneralManager.class));
        boolean run = true;
        while (run) {
            System.out.println("Enter 1 to add a new employee");
            System.out.println("Enter 2 to view employee list");
            System.out.println("Enter 3 to delete an employee");
            System.out.println("Enter 0 to exit");
            int choice = sc.nextInt();
            sc.nextLine();
            switch (choice) {
                case 1:
                    addEmployee();
                    break;
                case 2:
                    viewEmployeeList();
                    break;
                case 3:
                    deleteEmployee();
                    break;
                case 0:
                    run = false;
                    break;
                default:
                    System.out.println("Invalid choice");
            }
        }
    }

    private static void deleteEmployee(){
        int id;
        System.out.println("Please enter id:");
        id = sc.nextInt();
        for(GeneralManager employee : employeeList){
            if(id == employee.getId()){
                Hibernate.delete(employee);
                System.out.println("You deleted employee successfully!");
                break;
            }
        }
    }
    private static void addEmployee() {
        System.out.println("Enter age: ");
        int age = sc.nextInt();
        System.out.println("Enter work experience: ");
        int workExperience = sc.nextInt();
        if(age - workExperience < 16){
            while(age - workExperience < 16 || age < 16){
                System.out.println("Your work experience or age is invalid");
                System.out.println("Please write your real age:");
                age = sc.nextInt();
                System.out.println("Please write your real work experience:");
                workExperience = sc.nextInt();
            }
        }
        System.out.println("Enter first name: ");
        String firstName = sc.next();
        System.out.println("Enter last name: ");
        String lastName = sc.next();
        System.out.println("Enter employee position: ");
        System.out.println("1. Intern");
        System.out.println("2. Employee");
        System.out.println("3. Manager");
        System.out.println("4. Regional Manager");
        System.out.println("5. General Manager");
        int position = sc.nextInt();
        int salary = 0;
        if(position == 5){
            System.out.println("Please inter your salary:");
            salary = sc.nextInt();
        }

        sc.nextLine();
        switch (position) {
            case 1:
                employeeList.add(new Intern(age, workExperience,firstName, lastName, salary));
                break;
            case 2:
                employeeList.add(new Employee(age, workExperience,firstName, lastName, salary));
                break;
            case 3:
                employeeList.add(new Manager(age, workExperience,firstName, lastName, salary));
                break;
            case 4:
                employeeList.add(new RegionalManager(age, workExperience,firstName, lastName, salary));
                break;
            case 5:
                employeeList.add(new GeneralManager(age, workExperience,firstName, lastName, salary));
                break;
            default:
                System.out.println("Invalid choice");
        }
        for(GeneralManager employee : employeeList){
            Hibernate.save(employee);
        }
    }

    private static void viewEmployeeList() {
        for (GeneralManager employee : Hibernate.getDataFromDB(GeneralManager.class)) {
            System.out.println(employee.getId());
            System.out.println(employee.getFirstName());
            System.out.println(employee.getLastName());
            System.out.println(employee.getAge());
            System.out.println(employee.getSalary());
            System.out.println(employee.getWorkExperience());
            System.out.println("--------------------------------------");
        }
    }
}