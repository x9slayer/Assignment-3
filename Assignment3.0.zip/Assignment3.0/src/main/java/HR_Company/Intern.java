package HR_Company;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;

@Entity
public class Intern extends Employee {


    public Intern(int age, int workExperience, String firstName, String lastName, int salary) {
        super( age, workExperience,firstName, lastName,salary);
        setSalary(5000);
    }

    public Intern() {
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getId() {
        return id;
    }
}
