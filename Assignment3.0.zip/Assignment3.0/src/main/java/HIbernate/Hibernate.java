package HIbernate;

import HR_Company.GeneralManager;
import org.hibernate.Session;
import org.hibernate.Transaction;

import java.util.List;

public class Hibernate {
    public static void save(Object employee) {
        ///Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // start a transaction
            ///transaction = session.beginTransaction();
            // save the student object
            session.saveOrUpdate(employee);
            // commit transaction
            //transaction.commit();
        } catch (Exception e) {
            //if (transaction != null) {
              //  transaction.rollback();
            //}
            e.printStackTrace();
        }
    }

    public static void delete(Object employee) {
        //Transaction transaction = null;
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            // start a transaction
            //transaction = session.beginTransaction();
            // save the student object
            session.delete(employee);
            // commit transaction
            //transaction.commit();
        } catch (Exception e) {

            e.printStackTrace();
        }
    }

    public static <T> List<T> getDataFromDB(Class<T> entityClass) {
        try (Session session = HibernateUtil.getSessionFactory().openSession()) {
            //return session.get(Car.class,0); // return one object
            return session.createQuery("FROM " + entityClass.getName(), entityClass).list(); // return list of objects
        }
    }
}